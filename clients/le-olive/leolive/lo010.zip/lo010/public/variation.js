(function () {
	'use strict';

	function getDefaultExportFromCjs (x) {
		return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
	}

	var shared = {
	    ID: "lo010",
	    VARIATION: "1",
	    CLIENT: "le-olive",
	    SITE: "leolive"
	  };
	var shared$1 = getDefaultExportFromCjs(shared);

	const setup = () => {
	  const { ID, VARIATION } = shared$1;
	  document.documentElement.classList.add(ID);
	  document.documentElement.classList.add(`${ID}-${VARIATION}`);
	};

	const pollerLite = (conditions, callback, maxTime = 10000) => {
	  const POLLING_INTERVAL = 25;
	  const startTime = Date.now();
	  const interval = setInterval(() => {
	    const allConditionsMet = conditions.every((condition) => {
	      if (typeof condition === 'function') {
	        return condition();
	      }
	      return !!document.querySelector(condition);
	    });
	    if (allConditionsMet) {
	      clearInterval(interval);
	      callback();
	    } else if (Date.now() - startTime >= maxTime) {
	      clearInterval(interval);
	      console.error('Polling exceeded maximum time limit');
	    }
	  }, POLLING_INTERVAL);
	};

	const crossIcon = `
   <svg role="img" width="35" height="35" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg" class="needsclick  kl-private-reset-css-Xuajs1"><title id="title-Close dialog">Close dialog</title><circle cx="10" cy="10" r="9.5" fill="rgba(180,187,195,0)" stroke="rgba(255,255,255,0)" style="cursor: pointer;"></circle><path d="M6 6L14 14M6 14L14 6L6 14Z" stroke="#373F47" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" style="cursor: pointer;"></path></svg>

    `;
	const arrow = `
        <svg width="6px" height="10px" viewBox="0 0 6 10" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
              <g id="Symbols" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                <g id="Element/Footer" transform="translate(-1237.000000, -388.000000)" fill="#141416" fill-rule="nonzero">
                  <path d="M1242.70917,392.313253 L1238.65147,388.27883 C1238.27755,387.907057 1237.65436,387.907057 1237.28044,388.27883 C1236.90652,388.650602 1236.90652,389.270224 1237.28044,389.641997 L1240.46993,393 L1237.28044,396.347676 C1236.90652,396.719449 1236.90652,397.339071 1237.28044,397.710843 C1237.47432,397.903614 1237.7236,398 1237.97288,398 C1238.22216,398 1238.47144,397.903614 1238.66532,397.710843 L1242.70917,393.690189 C1242.88921,393.511188 1243,393.263339 1243,393.001721 C1243,392.740103 1242.90306,392.492255 1242.70917,392.313253 Z" id="Path-Copy-14"></path>
                </g>
              </g>
            </svg>
    `;

	const modal = (id, data) => {
	  const { text, desc, colectionName, commonText, colectionUrl, cartUrl, cartText } = data;
	  const html = `
        <div class="${id}__modal">
            <div class="${id}__modal-overlay"></div>
            <div class="${id}__modal-container">
                <div class="${id}__modal-container-content">
                    <div class="${id}__promoTitle">${text}</div>
                    <div class="${id}__promoDesc">${desc}</div>
                     <a class="${id}__cartLink btn btn--sm btn--primary" href="${cartUrl}">
                        <span>${commonText} ${cartText}</span>
                        ${arrow}
                    </a>
                    <a class="${id}__collectionLink btn btn--sm btn--primary" href="${colectionUrl}">
                        <span>${commonText} ${colectionName}</span>
                        ${arrow}
                    </a>
                   
                    <div class="${id}__closeModal ${id}__closeIcon">${crossIcon}</div>
                </div>
            </div>
        </div>
    `;
	  return html;
	};

	const { ID, VARIATION } = shared$1;
	const cartCountElem = document.querySelector('#CartCount');
	const cartValue = Number(cartCountElem.dataset.count);
	const cartName = {
	  nl: 'winkelwagen',
	  de: 'Warenkorb',
	  fr: 'panier',
	  es: 'carro',
	  en: 'cart'
	};
	const gotoText = {
	  en: 'Go to',
	  fr: 'Aller à',
	  de: 'Gehe zu',
	  nl: 'Ga naar',
	  es: 'Ir a'
	};
	const init = () => {
	  const promoElement = document.querySelector('.product-single__form-banner');
	  const promoTitleElement = promoElement.querySelector('center');
	  const mainPromoText = promoTitleElement.querySelector('b').innerText.trim();
	  const promoDesc = promoTitleElement.innerText.trim().split(mainPromoText)[1];
	  const navElement = document.querySelector('.breadcrumb-nav > span');
	  const collectionElement =
	    navElement.querySelector('.breadcrumb-nav__separator + span[itemprop="itemListElement"] a') ||
	    document.querySelector('.product-single__subtitle');
	  const colectionUrl = collectionElement.href;
	  const collectionName =
	    collectionElement.querySelector('span')?.innerText.trim() || collectionElement.innerText.trim();
	  const cartUrl = window.Shopify.locale === 'en' ? '/cart' : `/${window.Shopify.locale}/cart`;
	  const data = {
	    text: mainPromoText,
	    desc: promoDesc,
	    colectionName: collectionName,
	    commonText: gotoText[window.Shopify.locale],
	    colectionUrl,
	    cartText: cartName[window.Shopify.locale],
	    cartUrl
	  };
	  if (!document.querySelector(`.${ID}__modal`)) {
	    document.body.insertAdjacentHTML('beforeend', modal(ID, data));
	  }
	};
	var activate = () => {
	  if (cartValue > 0) return;
	  setup();
	  if (VARIATION === 'control') return;
	  document.body.addEventListener('click', (e) => {
	    const { target } = e;
	    if (target.closest('#AddToCartNew') || target.closest('.product-single__floating-bar button')) {
	      const cartQuantity = Number(cartCountElem.innerText.trim());
	      if (cartQuantity > 1) return;
	      const modalWrapper = document.querySelector(`.${ID}__modal`);
	      modalWrapper.classList.add('open');
	      pollerLite(['body.header-cart__sidebar-visible'], () => {
	        const bodyElement = document.body;
	        bodyElement.classList.remove('header-cart__sidebar-visible');
	      });
	    } else if (target.closest(`.${ID}__closeModal`) || target.closest(`.${ID}__modal-overlay`)) {
	      const modalWrapper = document.querySelector(`.${ID}__modal`);
	      modalWrapper.classList.remove('open');
	      window.location.reload();
	    }
	  });
	  init();
	};

	pollerLite(['body.template-product', '#CartCount', '.product-single__form-banner'], activate);

})();
